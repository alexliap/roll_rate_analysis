# Roll Rate Analysis

Roll rate analysis is a type of analysis made in the sector of credit risk and is used to define the target variable. More specifically, it is used in the creation of Risk, Application, and Behaviour Scorecards. Usually, it is a multiple iteration process which makes the process difficult if someone is working on custom code. The purpose of this package is to make the process easier by parametrizing a lot of factors needed in each case and iteration.

It is currently under development.
